package com.mongo.mongodb;

import org.springframework.data.mongodb.repository.MongoRepository;
public interface StudentRepo extends MongoRepository<Student, Integer>{
}
